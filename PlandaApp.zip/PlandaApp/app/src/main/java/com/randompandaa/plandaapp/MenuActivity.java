package com.randompandaa.plandaapp;

import android.app.Activity;

public class MenuActivity extends Activity {
}
